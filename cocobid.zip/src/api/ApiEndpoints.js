export const SIGNIN_URL = '/api/signinuser';
export const SIGNUP_URL = '/api/registeruser';
export const VERIFY_USER_URL = '/api/verifyuser';
export const SUBMIT_AUCTION_URL = '/api/auction';
export const GET_AUCTION_DATA_URL = '/api/getauction';
    ;
//

//admin apis
export const FETCH_ALL_STAFF = '/api/fetchstaff';
export const FETCH_ALL_CATEGORIES = '/api/fetchallcategories';
export const FETCH_ALL_FOODS = '/api/fetchallfoods';
