import { INCREASE_VALUE } from "../constants/ActionTypes";
export const IncreaseValueAction =()=>{
    return{
        type:INCREASE_VALUE
    }
}