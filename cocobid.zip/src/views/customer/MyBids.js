import React, { useEffect, useState } from 'react'
import '../../styles/Customer/Bids.css';
import { useNavigate } from 'react-router-dom';
import BidCard from '../../components/BidCard';
import ReactDOM from 'react-dom';
import Modal from 'react-modal';
import Picker from '../../components/DateTimePicker';
import Axios from '../../api/Axios';
import * as API_ENDPOINTS from '../../api/ApiEndpoints';
export default function MyBids() {
  const [modalIsOpen, setIsOpen] = useState(false);
  const [datetime, setDateTime] = useState();
  const [description, setDescription] = useState();
  const [price, setPrice] = useState();
  const [value, onChange] = useState(new Date());
  const [auction, setAuction] = useState()
  const [triggerUseEffect, setTrigger] = useState(false);
  const ValuePiece = Date | null;

  const Value = ValuePiece | [ValuePiece, ValuePiece];
  const navigate = useNavigate();
  const navigateTo = (page) => {
    navigate('/' + page);
  };
  let subtitle;
  const customStyles = {
    content: {
      top: '50%',
      left: '50%',
      right: 'auto',
      bottom: 'auto',
      marginRight: '-50%',
      transform: 'translate(-50%, -50%)',
      width: '60%',
      height: '70%'
    },
  };
  Modal.setAppElement('body');
  const openModal = () => {
    setIsOpen(true);
  }
  const closeModal = () => {
    setIsOpen(false);
  }
  const afterOpenModal = () => {
    // references are now sync'd and can be accessed.
    subtitle.style.color = '#000';
  }
  const handleSubmit = () => {
    //console.log((auction[0]))
    const date = new Date(datetime.$d);
    Axios.post(API_ENDPOINTS.SUBMIT_AUCTION_URL, {
      userId: sessionStorage.getItem('user_id'),
      closingdate: date,
      basePrice: price,
      auctionDescription: description
    }).then((response) => {
      setTrigger(!triggerUseEffect);
      console.log(response.data)
    })
  }
  useEffect(() => {
    async function fetchData() {
      const auction = await Axios.post(API_ENDPOINTS.GET_AUCTION_DATA_URL, {
        userId: sessionStorage.getItem('user_id'),
      });
      console.log(typeof (auction.data.data))
      setAuction(auction.data.data);

    }
    fetchData();
    //setCategories()
    // Axios.post(API_ENDPOINTS.FETCH_ALL_PRODUCTS).then((result) => {
    // 	console.log(result.data)
    // 	setFoods(result.data);
    // 	dispatch(ALL_ACTIONS.setAllProducts(result.data));
    // 	//allFoods = useSelector((state) => state.userReducer.allProducts);
    // });
  }, [triggerUseEffect]);
  return (
    <div className='customerBids'>
      <BidCard type='new' fun={openModal} />
      {auction && auction.map((item) => (
        <BidCard type='current' data={item} />
      ))}
      <Modal
        isOpen={modalIsOpen}
        onAfterOpen={afterOpenModal}
        onRequestClose={closeModal}
        style={customStyles}
        contentLabel="Example Modal"
      >
        <h2 ref={(_subtitle) => (subtitle = _subtitle)}>Create an Auction</h2>
        <div style={{
          width: '100%',
          height: '80%',
          display: 'flex',
          flexDirection: 'column'
        }}>
          <textarea style={{
            width: '95%',
            height: '40%',
            resize: 'none',
            outline: '1px solid black'

          }}
            placeholder="Description..."
            onChange={(event) => setDescription(event.target.value)}
          >

          </textarea>
          <div>
            <input className='signInInput' style={{ width: '40%' }} type='currency' required placeholder='Base Price (Rs.)' onChange={(event) => setPrice(event.target.value)}></input>
          </div>
          <Picker onChange={setDateTime} />
          <div className='bid_btn' style={{ marginTop: '3%' }} onClick={handleSubmit}>
            Place
          </div>



        </div>
      </Modal>
    </div>
  );

}
