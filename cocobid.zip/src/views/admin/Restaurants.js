import React from 'react'

export default function Restaurants() {
  return (
    <div>Restaurants</div>
  )
}
